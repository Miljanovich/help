HM = {}
HM = setmetatable(HM, {})
HM.Version = 'v1.0.1'

--Edit below here
HM.discord = 'https://discord.gg/sjAwVPT2zp'     --Discord link                            
HM.tebex = ''       --Tebex link
HM.website = ''     --Website link

HM.mn = 'City Handbook'      --Menu Name
HM.sn = 'server-name'        --Server Name
HM.desc = 'This is the description for the menu, to answer any of your questions'  --Menu Description 

HM.Command = 'Help'          -- command to open Help Menu
HM.Bind = true               -- false will disable the keybind feature
HM.keybind = 'F9'            -- If you would like to change the keybind key this is where you do it